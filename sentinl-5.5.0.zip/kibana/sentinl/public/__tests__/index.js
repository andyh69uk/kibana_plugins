describe('Sentinl', function () {
  require('../controllers/__tests__/reportController');
});
